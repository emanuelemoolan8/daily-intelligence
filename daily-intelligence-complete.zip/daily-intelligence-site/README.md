# Daily Intelligence — bilingual newspaper

A static reader with English/Malayalam editions, browser text-to-speech, short/full reading modes and a daily archive. A GitHub Actions workflow can generate and publish a new edition automatically using the OpenAI API and web search.

## One-time setup

1. Upload **all contents of this folder**, including the hidden `.github` folder, to the root of the public `emanuelemoolan8/daily-intelligence` repository. The `.github` folder is essential for automation.
2. GitHub repository **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**. Site URL: `https://emanuelemoolan8.github.io/daily-intelligence/`.
3. Create an OpenAI **API key** with billing enabled. This is separate from ChatGPT Plus. **Never commit the key.**
4. GitHub repository **Settings → Secrets and variables → Actions → New repository secret**. Name it `OPENAI_API_KEY`; paste the key as the value.
5. Repository **Actions → Publish Daily Intelligence → Run workflow**. Check the run logs, inspect the resulting `editions/YYYY-MM-DD.json`, and refresh the site. Then scheduled runs occur at around 08:10 Europe/Rome (GitHub Actions may delay scheduled jobs).
6. Ensure repository **Settings → Actions → General → Workflow permissions** allows the workflow to write contents, or its commit step may fail. The workflow declares `contents: write`.

## How it works

The GitHub Actions schedule runs at 06:10 and 07:10 UTC; the Python script checks the Europe/Rome clock and publishes only during local hour 08. This handles daylight saving without changing cron manually. It will never overwrite an existing edition for that date. On failure, it exits without adding an edition; investigate the GitHub Actions logs. The first run can be launched manually.

The generator uses the OpenAI Responses API with web search, then checks the JSON structure, both languages, six desks, story counts and HTTPS citation fields. **These checks cannot prove factual accuracy or that linked sources actually substantiate claims.** AI-assisted news should be editorially reviewed before being treated as verified. Market/weather data and forecasts should never be assumed accurate without source checking.

## Limitations

- The 10-minute/full modes are editorial modes, not guaranteed durations. Length is dependent on content and speech rate.
- Malayalam speech requires a Malayalam voice installed and available to the browser. Background audio may stop on Android.
- GitHub Pages is **public**. Do not publish private Gmail, calendar, account, portfolio or other sensitive personal data.
- GitHub Actions and OpenAI API have usage limits/costs; GitHub scheduled runs are not guaranteed to start exactly on time.
- This workflow is **separate** from any existing ChatGPT scheduled briefing; consider disabling one only if you explicitly want to avoid duplicate generation.
- The demo edition is a placeholder, not actual current news.
